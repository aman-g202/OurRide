package com.ourride.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.ourride.R;
import com.ourride.apis.ApiConfig;
import com.ourride.constant.Constant;
import com.ourride.ui.activity.EditProfileActivity;
import com.ourride.ui.fragment.BookingFragment;
import com.ourride.ui.fragment.DashboardFragment;
import com.ourride.ui.fragment.HistoryFragment;
import com.ourride.ui.fragment.ProfileFragment;
import com.ourride.ui.fragment.RoleFragment;
import com.ourride.utils.BaseActivity;
import com.ourride.utils.FragmentUtils;
import com.ourride.utils.SharedPrefrence;
import com.ourride.volley.ApiRequest;
import com.ourride.volley.IApiResponse;

import org.json.JSONException;
import org.json.JSONObject;

import static com.android.volley.VolleyLog.TAG;

public class MainHomeActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener, IApiResponse {
    public static FragmentManager fragmentManager;
    public static FragmentUtils fragmentUtils;
    public static TextView tvEditProfile;
    public static Toolbar toolbar;
    public String nameUser;
    public String emailUser;
    public String phoneUser;
    public String userImageUrl;
    private ApiRequest apiRequest;
    private int user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        tvEditProfile = findViewById(R.id.tvEditProfile);
        tvEditProfile.setVisibility(View.GONE);
        tvEditProfile.setOnClickListener(this);
        mContext = MainHomeActivity.this;
        apiRequest = new ApiRequest(mContext, (IApiResponse)this);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        fragmentManager = getSupportFragmentManager();
        fragmentUtils = new FragmentUtils(fragmentManager);
        toolbar.setTitle("Home");
        fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        Fragment profile = fragmentManager.findFragmentByTag(Constant.ProfileFragment);
        Fragment myBooking = fragmentManager.findFragmentByTag(Constant.BookingFragment);
        Fragment history = fragmentManager.findFragmentByTag(Constant.HistoryFragment);
        Fragment role = fragmentManager.findFragmentByTag(Constant.RoleFragment);

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }

        if (profile != null) {
            fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
        }
        else if (myBooking != null) {
            fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
        }
        else if (history != null) {
            fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
        }
        else if (role != null) {
            fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
        }
        else {
            new AlertDialog.Builder(this)
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setTitle("Closing Activity")
                    .setMessage("Are you sure you want to close this app?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(Intent.ACTION_MAIN);
                            intent.addCategory(Intent.CATEGORY_HOME);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }

                    })
                    .setNegativeButton("No", null)
                    .show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_home, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.icDashBoard) {
            toolbar.setTitle(Constant.DashboardFragment);
            fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
        } else if (id == R.id.icProfile) {
            toolbar.setTitle(Constant.ProfileFragment);
            fragmentUtils.replaceFragment(new ProfileFragment(), Constant.ProfileFragment, R.id.main_frame);
        } else if (id == R.id.icMyBookings) {
            toolbar.setTitle(Constant.BookingFragment);
            fragmentUtils.replaceFragment(new BookingFragment(), Constant.BookingFragment, R.id.main_frame);
        } else if (id == R.id.icHistory) {
            toolbar.setTitle(Constant.HistoryFragment);
            fragmentUtils.replaceFragment(new HistoryFragment(), Constant.HistoryFragment, R.id.main_frame);
        } else if (id == R.id.icShare) {
            toolbar.setTitle("Home");
            fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
        } else if (id == R.id.icRole) {
            toolbar.setTitle("Role");
            fragmentUtils.replaceFragment(new RoleFragment(), Constant.RoleFragment, R.id.main_frame);
        } else if (id == R.id.icLogout) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvEditProfile:
                if (SharedPrefrence.getInt(mContext,"user_id") != 0){
                    user_id = SharedPrefrence.getInt(mContext,"user_id");
                    apiRequest.postRequest(ApiConfig.baseUrl+"view/"+user_id+".json", "ShowProfile", Request.Method.GET);
                }else{
                    Toast.makeText(mContext, "Oops, some error occured contact admin", Toast.LENGTH_LONG).show();
                }
                break;

        }
    }

    @Override
    public void onResultReceived(String response, String tag_json_obj) throws JSONException {
        try {
            if (!"".equals(tag_json_obj)) {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.has("user")) {
                    JSONObject responseObject = jsonObject.getJSONObject("user");
                    if (responseObject.has("name")){
                        nameUser = responseObject.getString("name");
                    }
                    emailUser = responseObject.getString("email");
                    phoneUser =responseObject.getString("phone");
                    userImageUrl = responseObject.getString("profile_image_url");
                    Intent intent = new Intent(mContext, EditProfileActivity.class);
                    intent.putExtra("name",nameUser);
                    intent.putExtra("email", emailUser);
                    intent.putExtra("phone", phoneUser);
                    intent.putExtra("user_image_url", userImageUrl);
//                    Toast.makeText(mContext, responseObject.getString("profile_image_url"), Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }else{
                    Toast.makeText(mContext, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                }
            }
        }catch (Exception e){
            Log.d("aman", e.getMessage());
        }

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Log.d(TAG, error.getMessage());
    }
}
