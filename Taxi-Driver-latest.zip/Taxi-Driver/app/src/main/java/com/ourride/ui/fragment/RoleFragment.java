package com.ourride.ui.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.ourride.R;
import com.ourride.constant.Constant;
import com.ourride.ui.MainHomeActivity;
import com.ourride.utils.BaseFragment;
import com.ourride.utils.SharedPrefrence;

import static com.ourride.ui.MainHomeActivity.tvEditProfile;

public class RoleFragment extends BaseFragment {
    private View rootView;
    private Button driverButton, wingmanButton;
    private TextView roleTextView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_role, container, false);
        tvEditProfile.setVisibility(View.GONE);
        mContext = getActivity();
        activity = getActivity();
        init();
        return rootView;
    }

    private void init() {
        driverButton = rootView.findViewById(R.id.driverButton);
        wingmanButton = rootView.findViewById(R.id.passengerButton);
        roleTextView = rootView.findViewById(R.id.roleTextView);

        roleTextView.setText("Your Current Role is " + SharedPrefrence.get(mContext, "role"));

        driverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPrefrence.save(mContext, "role", "Driver");
                Toast.makeText(mContext, "Your Role Updated!", Toast.LENGTH_LONG).show();
                MainHomeActivity.fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
            }
        });
        wingmanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPrefrence.save(mContext, "role", "Wingman");
                Toast.makeText(mContext, "Your Role Updated!", Toast.LENGTH_LONG).show();
                MainHomeActivity.fragmentUtils.replaceFragment(new DashboardFragment(), Constant.DashboardFragment, R.id.main_frame);
            }
        });
    }

}
