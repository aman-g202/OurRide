package com.ourride.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.ourride.R;
import com.ourride.constant.Constant;
import com.ourride.ui.MainHomeActivity;
import com.ourride.ui.activity.MapActivity;
import com.ourride.ui.activity.WingmenActivity;
import com.ourride.utils.BaseFragment;
import com.ourride.utils.SharedPrefrence;

import static com.ourride.ui.MainHomeActivity.tvEditProfile;

public class DashboardFragment extends BaseFragment implements View.OnClickListener{
    private View rootView;
    private ImageView mapImageView, profileImageView, bookingsImageView, historyImageView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_dashboard, container, false);
        mContext = getActivity();
        activity = getActivity();
        tvEditProfile.setVisibility(View.GONE);
        init();
        return rootView;
    }

    private void init () {
        mapImageView = rootView.findViewById(R.id.mapView);
        profileImageView = rootView.findViewById(R.id.profileView);
        bookingsImageView = rootView.findViewById(R.id.bookingsView);
        historyImageView = rootView.findViewById(R.id.historyView);

        mapImageView.setOnClickListener(this);
        profileImageView.setOnClickListener(this);
        bookingsImageView.setOnClickListener(this);
        historyImageView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mapView:
                if (SharedPrefrence.get(mContext, "role") == "Driver") {
                    startActivity(new Intent(mContext, MapActivity.class));
                }
                else if (SharedPrefrence.get(mContext, "role") == "Wingman") {
                    startActivity(new Intent(mContext, WingmenActivity.class));
                }
                break;
            case R.id.profileView:
                MainHomeActivity.fragmentUtils.replaceFragment(new ProfileFragment(), Constant.ProfileFragment, R.id.main_frame);
                break;
            case R.id.bookingsView:
                MainHomeActivity.fragmentUtils.replaceFragment(new BookingFragment(), Constant.BookingFragment, R.id.main_frame);
                break;
            case R.id.historyView:
                MainHomeActivity.fragmentUtils.replaceFragment(new HistoryFragment(), Constant.HistoryFragment, R.id.main_frame);
                break;
        }
    }

}
