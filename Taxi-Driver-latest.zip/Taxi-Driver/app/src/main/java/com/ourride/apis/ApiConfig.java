package com.ourride.apis;

public class ApiConfig {
    public static String baseUrl = "http://3.18.88.39/api/users/";
    public static String signUpDriver = "add.json";
    public static String loginDriver_passenger = "login.json";
}
