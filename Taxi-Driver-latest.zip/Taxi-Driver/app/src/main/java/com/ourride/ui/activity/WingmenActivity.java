package com.ourride.ui.activity;

import android.support.v7.app.AppCompatActivity;

public class WingmenActivity extends AppCompatActivity {
}
