package com.ourride.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.ourride.R;
import com.ourride.ui.MainHomeActivity;
import com.ourride.utils.SharedPrefrence;

public class SelectionActivity extends AppCompatActivity {

    private Button driverButton, passengerButton;
    private Context mContext;
    private Toolbar toolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);
        mContext = SelectionActivity.this;

        driverButton = findViewById(R.id.driverButton);
        passengerButton = findViewById(R.id.passengerButton);
        toolbar= findViewById(R.id.toolbar);
        toolbar.setTitle("Role");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        driverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPrefrence.save(mContext, "role", "Driver");
                startActivity(new Intent(SelectionActivity.this, MainHomeActivity.class));
            }
        });

        passengerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPrefrence.save(mContext, "role", "Wingman");
                startActivity(new Intent(SelectionActivity.this, MainHomeActivity.class));
            }
        });

//        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.M) {
//            checkPermission();
//        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
